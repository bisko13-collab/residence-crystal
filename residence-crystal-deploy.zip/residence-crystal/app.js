/* ============================================
   RÉSIDENCE CONNECT — Gestion des Données
   LocalStorage | Offline | Algérie 🇩🇿
   ============================================ */

const DB = {
  // Clés de stockage
  keys: {
    messages: 'rc_messages',
    annonces: 'rc_annonces',
    prestataires: 'rc_prestataires',
    stats: 'rc_stats',
    config: 'rc_config',
    user: 'rc_user'
  },

  // Initialiser la base de données
  init() {
    if (!localStorage.getItem(this.keys.config)) {
      this.set(this.keys.config, {
        residence: 'Résidence Crystal',
        ville: 'Oran',
        promoteur: 'Benammar',
        syndicPhone: '0542194183',
        syndicEmail: 'syndic@residence-crystal.dz',
        urgencePhone: '1548',
        groupeWhatsApp: 'https://chat.whatsapp.com/C3EA78XnUaPFIGqeMCAWko',
        langue: 'fr',
        theme: 'light',
        version: '1.0.0'
      });
    }
    
    if (!localStorage.getItem(this.keys.prestataires)) {
      this.set(this.keys.prestataires, [
        { nom: 'Omar', specialite: 'Plomberie & Électricité', phone: '213542194183', icon: '🔧', note: 4.8 },
        { nom: 'Karim', specialite: 'Menuiserie', phone: '213554433221', icon: '🪚', note: 4.5 },
        { nom: 'Sofiane', specialite: 'Peinture', phone: '213661122334', icon: '🎨', note: 4.7 },
        { nom: 'Amine', specialite: 'Climatisation', phone: '213772233445', icon: '❄️', note: 4.9 },
        { nom: 'Hassan', specialite: 'Serrurerie', phone: '213553344556', icon: '🔐', note: 4.6 },
        { nom: 'Lamine', specialite: 'Nettoyage', phone: '213667788990', icon: '🧹', note: 4.4 }
      ]);
    }
    
    if (!localStorage.getItem(this.keys.annonces)) {
      this.set(this.keys.annonces, [
        { id: 1, type: 'location', titre: 'F3 meublé - 75m²', description: 'Appartement F3 entièrement meublé, 2 chambres, salon, cuisine équipée. Disponible immédiatement.', prix: '45000 DA/mois', contact: '213554433221', date: '2026-08-10', appartement: 'B-12' },
        { id: 2, type: 'vente', titre: 'F4 - 120m²', description: 'Magnifique F4 avec vue sur mer, 3 chambres, 2 salles de bain, terrasse 20m².', prix: '2800000 DA', contact: '213661122334', date: '2026-08-08', appartement: 'A-05' },
        { id: 3, type: 'colocation', titre: 'Chambre en colocation', description: 'Cherche colocataire pour chambre dans F3. Étudiant(e) ou jeune actif(ve).', prix: '15000 DA/mois', contact: '213772233445', date: '2026-08-05', appartement: 'C-08' }
      ]);
    }
    
    if (!localStorage.getItem(this.keys.stats)) {
      this.set(this.keys.stats, {
        totalMessages: 0,
        totalAnnonces: 3,
        totalPrestataires: 6,
        messagesParCategorie: { plainte: 0, urgence: 0, syndic: 0, suggestion: 0, autre: 0 },
        derniereActivite: new Date().toISOString()
      });
    }
  },

  // Récupérer des données
  get(key) {
    try {
      return JSON.parse(localStorage.getItem(key));
    } catch {
      return null;
    }
  },

  // Sauvegarder des données
  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },

  // Ajouter un message
  addMessage(message) {
    const messages = this.get(this.keys.messages) || [];
    message.id = Date.now();
    message.date = new Date().toISOString();
    message.lu = false;
    messages.unshift(message);
    this.set(this.keys.messages, messages);
    
    // Mettre à jour les stats
    const stats = this.get(this.keys.stats);
    stats.totalMessages++;
    stats.messagesParCategorie[message.categorie] = (stats.messagesParCategorie[message.categorie] || 0) + 1;
    stats.derniereActivite = new Date().toISOString();
    this.set(this.keys.stats, stats);
    
    return message;
  },

  // Récupérer les messages
  getMessages(filtre = null) {
    const messages = this.get(this.keys.messages) || [];
    if (filtre) {
      return messages.filter(m => m.categorie === filtre);
    }
    return messages;
  },

  // Marquer comme lu
  markAsRead(id) {
    const messages = this.get(this.keys.messages) || [];
    const msg = messages.find(m => m.id === id);
    if (msg) {
      msg.lu = true;
      this.set(this.keys.messages, messages);
    }
  },

  // Supprimer un message
  deleteMessage(id) {
    let messages = this.get(this.keys.messages) || [];
    messages = messages.filter(m => m.id !== id);
    this.set(this.keys.messages, messages);
  },

  // Ajouter une annonce
  addAnnonce(annonce) {
    const annonces = this.get(this.keys.annonces) || [];
    annonce.id = Date.now();
    annonce.date = new Date().toISOString();
    annonces.unshift(annonce);
    this.set(this.keys.annonces, annonces);
    
    const stats = this.get(this.keys.stats);
    stats.totalAnnonces++;
    stats.derniereActivite = new Date().toISOString();
    this.set(this.keys.stats, stats);
    
    return annonce;
  },

  // Récupérer les annonces
  getAnnonces(filtre = null) {
    const annonces = this.get(this.keys.annonces) || [];
    if (filtre) {
      return annonces.filter(a => a.type === filtre);
    }
    return annonces;
  },

  // Supprimer une annonce
  deleteAnnonce(id) {
    let annonces = this.get(this.keys.annonces) || [];
    annonces = annonces.filter(a => a.id !== id);
    this.set(this.keys.annonces, annonces);
  },

  // Récupérer les prestataires
  getPrestataires() {
    return this.get(this.keys.prestataires) || [];
  },

  // Récupérer la config
  getConfig() {
    return this.get(this.keys.config) || {};
  },

  // Mettre à jour la config
  updateConfig(updates) {
    const config = this.getConfig();
    Object.assign(config, updates);
    this.set(this.keys.config, config);
  },

  // Récupérer les stats
  getStats() {
    return this.get(this.keys.stats) || {};
  },

  // Exporter toutes les données
  export() {
    return {
      config: this.getConfig(),
      messages: this.getMessages(),
      annonces: this.getAnnonces(),
      prestataires: this.getPrestataires(),
      stats: this.getStats(),
      exportDate: new Date().toISOString()
    };
  },

  // Importer des données
  import(data) {
    if (data.config) this.set(this.keys.config, data.config);
    if (data.messages) this.set(this.keys.messages, data.messages);
    if (data.annonces) this.set(this.keys.annonces, data.annonces);
    if (data.prestataires) this.set(this.keys.prestataires, data.prestataires);
    if (data.stats) this.set(this.keys.stats, data.stats);
  },

  // Réinitialiser
  reset() {
    Object.values(this.keys).forEach(key => localStorage.removeItem(key));
    this.init();
  }
};

// Initialiser au chargement
DB.init();

/* ============================================
   UTILITAIRES
   ============================================ */

const Utils = {
  // Formater une date
  formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'À l\'instant';
    if (diff < 3600) return `Il y a ${Math.floor(diff / 60)} min`;
    if (diff < 86400) return `Il y a ${Math.floor(diff / 3600)} h`;
    if (diff < 604800) return `Il y a ${Math.floor(diff / 86400)} j`;
    
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
  },

  // Formater un numéro de téléphone algérien
  formatPhone(phone) {
    const clean = phone.replace(/\D/g, '');
    if (clean.startsWith('213')) {
      return `+${clean.slice(0, 3)} ${clean.slice(3, 5)} ${clean.slice(5, 8)} ${clean.slice(8, 10)} ${clean.slice(10, 12)}`;
    }
    if (clean.startsWith('0')) {
      return clean.replace(/(\d{2})(\d{3})(\d{2})(\d{2})/, '$1 $2 $3 $4');
    }
    return clean;
  },

  // Générer un lien WhatsApp
  whatsappLink(phone, message = '') {
    const clean = phone.replace(/\D/g, '');
    const formatted = clean.startsWith('213') ? clean : `213${clean.slice(1)}`;
    const encodedMsg = encodeURIComponent(message);
    return `https://wa.me/${formatted}${encodedMsg ? '?text=' + encodedMsg : ''}`;
  },

  // Générer un QR code SVG simple
  generateQR(data, size = 150) {
    // Utiliser une API externe pour le QR code
    return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(data)}`;
  },

  // Copier dans le presse-papier
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return true;
    }
  },

  // Partager (Web Share API)
  async share(data) {
    if (navigator.share) {
      try {
        await navigator.share(data);
        return true;
      } catch {
        return false;
      }
    }
    return false;
  },

  // Toast notification
  toast(message, type = 'info', duration = 3000) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('hiding');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },

  // Vérifier si online
  isOnline() {
    return navigator.onLine;
  },

  // Debounce
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
};

// Écouter les changements de connexion
window.addEventListener('online', () => Utils.toast('Connexion rétablie !', 'success'));
window.addEventListener('offline', () => Utils.toast('Mode hors ligne activé', 'info'));
