# 🚀 GUIDE DÉPLOIEMENT RAPIDE — Résidence Connect

## Option 1 : Netlify (RECOMMANDÉ — 2 minutes)

### Étape 1 : Va sur netlify.com
- Ouvre ton navigateur (Chrome/Safari) sur téléphone ou ordinateur
- Va sur : https://www.netlify.com
- Clique sur **"Add new site"** → **"Deploy manually"** (déploiement manuel)

### Étape 2 : Upload le ZIP
- Glisse-dépose le fichier **residence-crystal-deploy.zip**
- OU clique sur "Browse" et sélectionne le ZIP
- Attends 10 secondes le déploiement

### Étape 3 : Récupère l'URL
- Netlify te donne une URL du type : `https://residence-crystal-123456.netlify.app`
- **Renomme-la** (clique sur "Site settings" → "Change site name") en :
  - `residence-crystal.netlify.app` (si dispo)
  - OU `benammar-crystal.netlify.app`
  - OU `residence-connect-oran.netlify.app`

### Étape 4 : Teste
- Ouvre l'URL sur ton téléphone
- Vérifie que l'app s'affiche
- Vérifie que le QR code fonctionne
- Vérifie que WhatsApp s'ouvre quand tu cliques

---

## Option 2 : GitHub Pages (5 minutes)

### Étape 1 : Crée un compte GitHub
- Va sur https://github.com
- Crée un compte (gratuit)

### Étape 2 : Crée un repository
- Nom : `residence-crystal`
- Visibilité : **Public** (obligatoire pour GitHub Pages gratuit)

### Étape 3 : Upload les fichiers
- Clique sur "Add file" → "Upload files"
- Glisse le contenu du dossier `residence-crystal/` (PAS le ZIP, les fichiers un par un)
- Commit

### Étape 4 : Active GitHub Pages
- Va dans Settings → Pages
- Source : Deploy from a branch → Branch: main → Folder: / (root)
- Sauvegarde
- Attends 2 minutes
- L'URL sera : `https://TON_USERNAME.github.io/residence-crystal/`

---

## Option 3 : Surge.sh (1 minute — ultra simple)

### Si tu as Node.js sur ton ordi :
```bash
npm install -g surge
surge /chemin/vers/residence-crystal/
```
- Choisis un nom : `residence-crystal.surge.sh`
- C'est en ligne instantanément

---

## ⚠️ POINTS IMPORTANT APRÈS DÉPLOIEMENT

### 1. Mets à jour le QR code
Dans `index.html`, cherche la ligne avec le QR code et remplace l'URL par la tienne :
```javascript
const url = 'https://TON-URL.netlify.app';  // ← Remplace ici
```

### 2. Mets à jour le manifest.json
```json
"start_url": "https://TON-URL.netlify.app/index.html"
```

### 3. Mets à jour les liens WhatsApp du syndic
Dans `app.js` et `index.html`, vérifie que le numéro WhatsApp du syndic est le bon :
```javascript
syndicPhone: '213542194183'  // ← Mets le vrai numéro de Benammar
```

### 4. Teste sur 4G (pas WiFi)
- Coupe le WiFi sur ton téléphone
- Ouvre l'URL en 4G
- Vérifie que tout charge
- Vérifie que l'app s'installe (bouton "Ajouter à l'écran d'accueil")

---

## 🎯 POUR LE RENDEZ-VOUS DEMAIN

### Ce que tu montres à Benammar :
1. **L'URL sur ton téléphone** : "Monsieur, scannez ce QR code, l'app s'installe"
2. **Tu lui envoies l'URL par WhatsApp** pour qu'il teste chez lui
3. **Tu montres le dashboard** : `https://TON-URL.netlify.app/admin.html`

### URLs à préparer :
- App résidents : `https://TON-URL.netlify.app/`
- Dashboard admin : `https://TON-URL.netlify.app/admin.html`
- Proposition : `https://TON-URL.netlify.app/proposition.html`
- Contrat : `https://TON-URL.netlify.app/contrat.html`

---

## 📱 ASTUCE PRO

Crée un **QR code** qui pointe vers ton URL déployée :
- Va sur https://qr-code-generator.com
- Colle ton URL
- Télécharge le QR en HD
- Imprime-le sur une feuille A4
- Montre-le à Benammar : "Vos résidents scanneront ça, et l'app s'installe"

---

## 🆘 SI ÇA NE MARCHE PAS

**Problème :** L'app ne s'affiche pas
**Solution :** Vérifie que les fichiers sont à la racine (pas dans un sous-dossier)

**Problème :** WhatsApp ne s'ouvre pas
**Solution :** Normal sur ordinateur, ça marche sur téléphone. Teste sur mobile.

**Problème :** Le QR code ne marche pas
**Solution :** Le QR code généré par l'app utilise l'URL actuelle. Si tu testes en local, il pointe vers `file://`. Il faut le tester sur l'URL déployée.

**Problème :** Je n'ai pas d'ordinateur
**Solution :** Netlify fonctionne sur téléphone ! Va sur netlify.com dans Chrome mobile, crée un compte, upload le ZIP depuis ton téléphone.

---

Bonne chance pour le déploiement ! 🇩🇿🔥
